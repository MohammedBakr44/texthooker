import { useState, useEffect, useRef } from "preact/hooks";
export function App() {
    const [charCount, setCharCount] = useState(0);
    const [lineCount, setLineCount] = useState(0);
    const newText = useRef({ text: [] });
    useEffect(() => {
        const oldText = localStorage.getItem("text");
        const container = document.querySelector("body");
        const config = { childList: true, attributes: false };

        if (oldText) {
            JSON.parse(oldText).text.forEach((element) => {
                container.innerHTML += `<p>${element}</p>`;
            });
        }

        const callback = (mutations) => {
            for (const mutation of mutations) {
                if (
                    mutation.addedNodes[0] &&
                    mutation.addedNodes[0].localName === "p"
                ) {
                    const text = mutation.addedNodes[0].innerText;
                    setCharCount(charCount + text.length);
                    setLineCount(lineCount + 1);
                    newText.current.text.push(text);
                    localStorage.setItem(
                        "text",
                        JSON.stringify(newText.current)
                    );
                }
            }
        };
        const observer = new MutationObserver(callback);
        observer.observe(container, config);
    }, []);

    return (
        <div className="app">
            <div className="remove">
                <span className="chars">
                    {charCount} / {lineCount}
                </span>
            </div>
        </div>
    );
}
